var dir_679a5f4dc6e016a7b897ec983fa5ad4a =
[
    [ "net8.0", "dir_5ddd91b32af2abcf37f9fb61e21b6208.html", "dir_5ddd91b32af2abcf37f9fb61e21b6208" ]
];