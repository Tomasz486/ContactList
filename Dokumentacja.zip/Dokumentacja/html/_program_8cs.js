var _program_8cs =
[
    [ "AddControllersWithViews", "_program_8cs.html#af8107f2f8ff8e8de22a684c8c8ad3e99", null ],
    [ "AddDbContext< AppDbContext >", "_program_8cs.html#a568e36371e9bbffb40fa54566bc11c88", null ],
    [ "if", "_program_8cs.html#af2d0c02efe3fbc2d94e5b6e316777c4d", null ],
    [ "MapControllerRoute", "_program_8cs.html#aec500e125fbbfcd3d99a23db7de60be7", null ],
    [ "Run", "_program_8cs.html#aaa3dbf02e269c3ef7e8546d290c6b3dd", null ],
    [ "UseAuthorization", "_program_8cs.html#af6f72d752b2e73aa0292f74bd13237ab", null ],
    [ "UseHttpsRedirection", "_program_8cs.html#aa4d447fc3129a3aa301d736b8bd04ae9", null ],
    [ "UseRouting", "_program_8cs.html#a94c810d266751293a2d511a720a5625f", null ],
    [ "UseStaticFiles", "_program_8cs.html#a906a3ce545279a7a73941f1d7b64d7cf", null ],
    [ "app", "_program_8cs.html#a7b225fcb720e4d5ed2bbf60e28a25e6d", null ],
    [ "builder", "_program_8cs.html#a2f78352277081c620fd4cf92a5ce15e5", null ]
];