var class_contact_list_1_1_models_1_1_contact_type =
[
    [ "ContactType", "class_contact_list_1_1_models_1_1_contact_type.html#a2b9c0b592ca9108aaf9e38024dcf403d", null ],
    [ "Id", "class_contact_list_1_1_models_1_1_contact_type.html#afba8640a42c7041afe7e032e4b5391e1", null ],
    [ "Type", "class_contact_list_1_1_models_1_1_contact_type.html#adcaadc4825cbbe68f2be8d5a49d7b76c", null ]
];