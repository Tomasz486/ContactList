var annotated_dup =
[
    [ "ContactList", "namespace_contact_list.html", [
      [ "Controllers", "namespace_contact_list_1_1_controllers.html", [
        [ "ContactController", "class_contact_list_1_1_controllers_1_1_contact_controller.html", "class_contact_list_1_1_controllers_1_1_contact_controller" ],
        [ "HomeController", "class_contact_list_1_1_controllers_1_1_home_controller.html", "class_contact_list_1_1_controllers_1_1_home_controller" ]
      ] ],
      [ "Models", "namespace_contact_list_1_1_models.html", [
        [ "AppDbContext", "class_contact_list_1_1_models_1_1_app_db_context.html", "class_contact_list_1_1_models_1_1_app_db_context" ],
        [ "Contact", "class_contact_list_1_1_models_1_1_contact.html", "class_contact_list_1_1_models_1_1_contact" ],
        [ "ContactType", "class_contact_list_1_1_models_1_1_contact_type.html", "class_contact_list_1_1_models_1_1_contact_type" ],
        [ "ContactWithAuth", "class_contact_list_1_1_models_1_1_contact_with_auth.html", "class_contact_list_1_1_models_1_1_contact_with_auth" ],
        [ "User", "class_contact_list_1_1_models_1_1_user.html", "class_contact_list_1_1_models_1_1_user" ],
        [ "UserData", "class_contact_list_1_1_models_1_1_user_data.html", "class_contact_list_1_1_models_1_1_user_data" ]
      ] ],
      [ "Services", "namespace_contact_list_1_1_services.html", [
        [ "AuthProvider", "class_contact_list_1_1_services_1_1_auth_provider.html", null ]
      ] ]
    ] ]
];