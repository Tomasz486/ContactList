var namespace_contact_list_1_1_services =
[
    [ "AuthProvider", "class_contact_list_1_1_services_1_1_auth_provider.html", null ]
];