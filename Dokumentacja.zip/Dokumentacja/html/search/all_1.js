var searchData=
[
  ['add_0',['Add',['../class_contact_list_1_1_controllers_1_1_contact_controller.html#a0f28624ff1cbaa6b958d9f0672cf7532',1,'ContactList::Controllers::ContactController']]],
  ['addcontrollerswithviews_1',['AddControllersWithViews',['../_program_8cs.html#af8107f2f8ff8e8de22a684c8c8ad3e99',1,'Program.cs']]],
  ['adddbcontext_3c_20appdbcontext_20_3e_2',['AddDbContext&lt; AppDbContext &gt;',['../_program_8cs.html#a568e36371e9bbffb40fa54566bc11c88',1,'Program.cs']]],
  ['app_3',['app',['../_program_8cs.html#a7b225fcb720e4d5ed2bbf60e28a25e6d',1,'Program.cs']]],
  ['appdbcontext_4',['AppDbContext',['../class_contact_list_1_1_models_1_1_app_db_context.html',1,'ContactList.Models.AppDbContext'],['../class_contact_list_1_1_models_1_1_app_db_context.html#a2fe96e16e9df74595b5f89f03f2f465e',1,'ContactList.Models.AppDbContext.AppDbContext()']]],
  ['appdbcontext_2ecs_5',['AppDbContext.cs',['../_app_db_context_8cs.html',1,'']]],
  ['aspnetmvceftemplate_2eassemblyinfo_2ecs_6',['AspNetMvcEFTemplate.AssemblyInfo.cs',['../_asp_net_mvc_e_f_template_8_assembly_info_8cs.html',1,'']]],
  ['aspnetmvceftemplate_2erazorassemblyinfo_2ecs_7',['AspNetMvcEFTemplate.RazorAssemblyInfo.cs',['../_asp_net_mvc_e_f_template_8_razor_assembly_info_8cs.html',1,'']]],
  ['authprovider_8',['AuthProvider',['../class_contact_list_1_1_services_1_1_auth_provider.html',1,'ContactList::Services']]],
  ['authprovider_2ecs_9',['AuthProvider.cs',['../_auth_provider_8cs.html',1,'']]]
];
