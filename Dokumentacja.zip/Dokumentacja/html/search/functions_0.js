var searchData=
[
  ['add_0',['Add',['../class_contact_list_1_1_controllers_1_1_contact_controller.html#a0f28624ff1cbaa6b958d9f0672cf7532',1,'ContactList::Controllers::ContactController']]],
  ['addcontrollerswithviews_1',['AddControllersWithViews',['../_program_8cs.html#af8107f2f8ff8e8de22a684c8c8ad3e99',1,'Program.cs']]],
  ['adddbcontext_3c_20appdbcontext_20_3e_2',['AddDbContext&lt; AppDbContext &gt;',['../_program_8cs.html#a568e36371e9bbffb40fa54566bc11c88',1,'Program.cs']]],
  ['appdbcontext_3',['AppDbContext',['../class_contact_list_1_1_models_1_1_app_db_context.html#a2fe96e16e9df74595b5f89f03f2f465e',1,'ContactList::Models::AppDbContext']]]
];
