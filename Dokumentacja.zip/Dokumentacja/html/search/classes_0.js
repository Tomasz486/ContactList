var searchData=
[
  ['appdbcontext_0',['AppDbContext',['../class_contact_list_1_1_models_1_1_app_db_context.html',1,'ContactList::Models']]],
  ['authprovider_1',['AuthProvider',['../class_contact_list_1_1_services_1_1_auth_provider.html',1,'ContactList::Services']]]
];
