var indexSectionsWithContent =
{
  0: ".abcdehilmprstu",
  1: "achu",
  2: "c",
  3: ".achpu",
  4: "acdehimrsu",
  5: "ab",
  6: "cdeilpstu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "properties"
};

var indexSectionLabels =
{
  0: "Wszystko",
  1: "Klasy",
  2: "Przestrzenie nazw",
  3: "Pliki",
  4: "Funkcje",
  5: "Zmienne",
  6: "Właściwości"
};

