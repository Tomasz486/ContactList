var searchData=
[
  ['useauthorization_0',['UseAuthorization',['../_program_8cs.html#af6f72d752b2e73aa0292f74bd13237ab',1,'Program.cs']]],
  ['usehttpsredirection_1',['UseHttpsRedirection',['../_program_8cs.html#aa4d447fc3129a3aa301d736b8bd04ae9',1,'Program.cs']]],
  ['userouting_2',['UseRouting',['../_program_8cs.html#a94c810d266751293a2d511a720a5625f',1,'Program.cs']]],
  ['usestaticfiles_3',['UseStaticFiles',['../_program_8cs.html#a906a3ce545279a7a73941f1d7b64d7cf',1,'Program.cs']]]
];
