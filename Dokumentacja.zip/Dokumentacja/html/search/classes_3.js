var searchData=
[
  ['user_0',['User',['../class_contact_list_1_1_models_1_1_user.html',1,'ContactList::Models']]],
  ['userdata_1',['UserData',['../class_contact_list_1_1_models_1_1_user_data.html',1,'ContactList::Models']]]
];
