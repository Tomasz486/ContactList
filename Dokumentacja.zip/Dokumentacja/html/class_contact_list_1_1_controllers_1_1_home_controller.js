var class_contact_list_1_1_controllers_1_1_home_controller =
[
    [ "Index", "class_contact_list_1_1_controllers_1_1_home_controller.html#aaa342ee58c9f8cd7e8910eb886d0d70b", null ]
];