var dir_5ddd91b32af2abcf37f9fb61e21b6208 =
[
    [ ".NETCoreApp,Version=v8.0.AssemblyAttributes.cs", "_8_n_e_t_core_app_00_version_0av8_80_8_assembly_attributes_8cs.html", null ],
    [ "AspNetMvcEFTemplate.AssemblyInfo.cs", "_asp_net_mvc_e_f_template_8_assembly_info_8cs.html", null ],
    [ "AspNetMvcEFTemplate.RazorAssemblyInfo.cs", "_asp_net_mvc_e_f_template_8_razor_assembly_info_8cs.html", null ],
    [ "ContactList.AssemblyInfo.cs", "_contact_list_8_assembly_info_8cs.html", null ],
    [ "ContactList.RazorAssemblyInfo.cs", "_contact_list_8_razor_assembly_info_8cs.html", null ]
];