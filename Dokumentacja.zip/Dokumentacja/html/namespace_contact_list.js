var namespace_contact_list =
[
    [ "Controllers", "namespace_contact_list_1_1_controllers.html", "namespace_contact_list_1_1_controllers" ],
    [ "Models", "namespace_contact_list_1_1_models.html", "namespace_contact_list_1_1_models" ],
    [ "Services", "namespace_contact_list_1_1_services.html", "namespace_contact_list_1_1_services" ]
];