var hierarchy =
[
    [ "ContactList.Services.AuthProvider", "class_contact_list_1_1_services_1_1_auth_provider.html", null ],
    [ "ContactList.Models.Contact", "class_contact_list_1_1_models_1_1_contact.html", [
      [ "ContactList.Models.ContactWithAuth", "class_contact_list_1_1_models_1_1_contact_with_auth.html", null ]
    ] ],
    [ "ContactList.Models.ContactType", "class_contact_list_1_1_models_1_1_contact_type.html", null ],
    [ "Controller", null, [
      [ "ContactList.Controllers.ContactController", "class_contact_list_1_1_controllers_1_1_contact_controller.html", null ],
      [ "ContactList.Controllers.HomeController", "class_contact_list_1_1_controllers_1_1_home_controller.html", null ]
    ] ],
    [ "DbContext", null, [
      [ "ContactList.Models.AppDbContext", "class_contact_list_1_1_models_1_1_app_db_context.html", null ]
    ] ],
    [ "ContactList.Models.User", "class_contact_list_1_1_models_1_1_user.html", null ],
    [ "ContactList.Models.UserData", "class_contact_list_1_1_models_1_1_user_data.html", null ]
];