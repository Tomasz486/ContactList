var namespaces_dup =
[
    [ "ContactList", "namespace_contact_list.html", "namespace_contact_list" ]
];