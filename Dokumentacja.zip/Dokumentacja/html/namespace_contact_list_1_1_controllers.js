var namespace_contact_list_1_1_controllers =
[
    [ "ContactController", "class_contact_list_1_1_controllers_1_1_contact_controller.html", "class_contact_list_1_1_controllers_1_1_contact_controller" ],
    [ "HomeController", "class_contact_list_1_1_controllers_1_1_home_controller.html", "class_contact_list_1_1_controllers_1_1_home_controller" ]
];