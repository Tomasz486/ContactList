var class_contact_list_1_1_models_1_1_contact =
[
    [ "ContactName", "class_contact_list_1_1_models_1_1_contact.html#a64e885773987f9bd555c7d9a6c3e70b8", null ],
    [ "DayOfBirth", "class_contact_list_1_1_models_1_1_contact.html#ae879fce5d2a0b9fba922691c046a86b1", null ],
    [ "Email", "class_contact_list_1_1_models_1_1_contact.html#a406bf8e2e6abfc18018b624d464a53b9", null ],
    [ "Id", "class_contact_list_1_1_models_1_1_contact.html#a7e39ff2fb71d76d7fb18dd10549ad8c1", null ],
    [ "Phone", "class_contact_list_1_1_models_1_1_contact.html#a7e39984eb2219ed485bc655fb24c6410", null ],
    [ "Surname", "class_contact_list_1_1_models_1_1_contact.html#a7de73edd1fba22cc944d42d3d48e0199", null ],
    [ "Type", "class_contact_list_1_1_models_1_1_contact.html#a1bc2c5d52b8ff599251c0eb2e812e0ea", null ]
];