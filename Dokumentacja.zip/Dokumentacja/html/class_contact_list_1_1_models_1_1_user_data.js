var class_contact_list_1_1_models_1_1_user_data =
[
    [ "Login", "class_contact_list_1_1_models_1_1_user_data.html#ae2c35c4f6680a3412c5947cac2b5f123", null ],
    [ "Password", "class_contact_list_1_1_models_1_1_user_data.html#a1341f17b0ee32b1bba46dd05c5fa00c7", null ],
    [ "Token", "class_contact_list_1_1_models_1_1_user_data.html#a1921a4b09753774c03fdfa03440e654e", null ]
];